package com.example.demo;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HashTagInput {
	
	@Autowired
	private HashTagRepository hashTagRepository;
	
	@Autowired
	private HashTagEntityTrendRepository hashTagTrendRepository;
	
	@Transactional
	@RequestMapping(value="/hashTag", method=RequestMethod.POST)
	public @ResponseBody List<HashTagEntityTrend> inputHashTag(@RequestBody String hashTag) {
		Pattern p = Pattern.compile(".*?\\s(#\\w+).*?"); 
		Matcher m = p.matcher(hashTag); 
		int count = 0;
		int trendCount =0;
	      while(m.find()) {
	         count++;
	         String hashTagName = hashTag.substring(m.start(), m.end());
	         HashTagEntity entity = new HashTagEntity();
	         entity.setId(Long.valueOf(DemoApplication.getRandom()));
	         entity.setTagName(hashTagName);
	         entity.setTagValue(hashTag);
	         hashTagRepository.insert(entity);
	         try {
	        	  trendCount = hashTagTrendRepository.findByTagCount(hashTagName);
					if (trendCount > 0) {					
							 trendCount = trendCount+1; 
						hashTagTrendRepository.updateTrendCount(trendCount,hashTagName);
					}
	         }catch(EmptyResultDataAccessException e) {
	        	 HashTagEntityTrend tagTrend = new HashTagEntityTrend();
					tagTrend.setHashTagCount(1);
					tagTrend.setHashTagName(hashTagName);
					tagTrend.setId(Long.valueOf(DemoApplication.getRandom()));
					hashTagTrendRepository.insert(tagTrend);  	 
	         }		 
	      }
	      return hashTagTrendRepository.findAll();
	}
}
