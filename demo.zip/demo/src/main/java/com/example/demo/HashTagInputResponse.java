package com.example.demo;

import java.util.List;

public class HashTagInputResponse {
	
	private List<HashTagEntityTrend> hashTagEntityTrend;
	private String reponseStatus;
	
	public List<HashTagEntityTrend> getHashTagEntityTrend() {
		return hashTagEntityTrend;
	}
	public void setHashTagEntityTrend(List<HashTagEntityTrend> hashTagEntityTrend) {
		this.hashTagEntityTrend = hashTagEntityTrend;
	}
	public String getReponseStatus() {
		return reponseStatus;
	}
	public void setReponseStatus(String reponseStatus) {
		this.reponseStatus = reponseStatus;
	}
	
	

}
